<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/fabianolivasbarriga/Documents/proyectos/app-demo/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>